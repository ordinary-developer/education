#include "recipe_5_01.h"
#include "recipe_5_02.h"
#include "recipe_5_03.h"
#include "recipe_5_04.h"
#include "recipe_5_05.h"
#include "recipe_5_06.h"
#include "recipe_5_07.h"
#include "recipe_5_08.h"
#include "recipe_5_09.h"
#include "recipe_5_10.h"

int main()
{
   recipe_5_01::execute();
   recipe_5_02::execute();
   recipe_5_03::execute();
   recipe_5_04::execute();
   recipe_5_05::execute();
   recipe_5_06::execute();
   recipe_5_07::execute();
   recipe_5_08::execute();
   recipe_5_09::execute();
   recipe_5_10::execute();
}
