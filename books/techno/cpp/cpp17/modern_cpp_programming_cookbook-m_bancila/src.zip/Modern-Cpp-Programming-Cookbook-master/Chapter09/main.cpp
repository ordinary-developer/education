#include "recipe_9_01.h"
#include "recipe_9_02.h"
#include "recipe_9_03.h"
#include "recipe_9_04.h"
#include "recipe_9_05.h"
#include "recipe_9_06.h"
#include "recipe_9_07.h"
#include "recipe_9_08.h"

int main()
{
   recipe_9_01::execute();
   recipe_9_02::execute();
   recipe_9_03::execute();
   recipe_9_04::execute();
   recipe_9_05::execute();
   recipe_9_06::execute();
   recipe_9_07::execute();
   recipe_9_08::execute();

   return 0;
}
