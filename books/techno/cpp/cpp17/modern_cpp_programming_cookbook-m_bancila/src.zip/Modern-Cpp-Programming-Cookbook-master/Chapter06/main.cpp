#include "recipe_6_01.h"
#include "recipe_6_02.h"
#include "recipe_6_03.h"
#include "recipe_6_04.h"
#include "recipe_6_05.h"
#include "recipe_6_06.h"
#include "recipe_6_07.h"
#include "recipe_6_08.h"
#include "recipe_6_09.h"
#include "recipe_6_10.h"
#include "recipe_6_11.h"

int main()
{
   recipe_6_01::execute();
   recipe_6_02::execute();
   recipe_6_03::execute();
   recipe_6_04::execute();
   recipe_6_05::execute();
   recipe_6_06::execute();
   recipe_6_07::execute();
   recipe_6_08::execute();
   recipe_6_09::execute();
   recipe_6_10::execute();
   recipe_6_11::execute();

   return 0;
}