#include "recipe_4_01.h"
#include "recipe_4_02.h"
#include "recipe_4_03.h"
#include "recipe_4_04.h"
#include "recipe_4_05.h"
#include "recipe_4_06.h"

int main()
{
   recipe_4_01::execute();
   recipe_4_02::execute();
   recipe_4_03::execute();
   recipe_4_04::execute();
   recipe_4_05::execute();
   recipe_4_06::execute();

   return 0;
}