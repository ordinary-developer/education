#include "recipe_3_01.h"
#include "recipe_3_02.h"
#include "recipe_3_03.h"
#include "recipe_3_04.h"
#include "recipe_3_05.h"
#include "recipe_3_06.h"
#include "recipe_3_07.h"
#include "recipe_3_08.h"
#include "recipe_3_09.h"

int main()
{
   recipe_3_01::execute();
   recipe_3_02::execute();
   recipe_3_03::execute();
   recipe_3_04::execute();
   recipe_3_05::execute();
   recipe_3_06::execute();
   recipe_3_07::execute();
   recipe_3_08::execute();
   recipe_3_09::execute();

   return 0;
}