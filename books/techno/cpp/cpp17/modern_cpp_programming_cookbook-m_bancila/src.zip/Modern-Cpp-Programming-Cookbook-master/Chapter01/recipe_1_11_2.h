#pragma once

namespace recipe_1_11
{
   void file2_run();
}