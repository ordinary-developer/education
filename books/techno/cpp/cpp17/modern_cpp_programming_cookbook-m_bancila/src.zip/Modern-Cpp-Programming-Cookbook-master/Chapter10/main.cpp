#include "recipe_10_01.h"
#include "recipe_10_02.h"
#include "recipe_10_03.h"
#include "recipe_10_04.h"
#include "recipe_10_05.h"
#include "recipe_10_06.h"
#include "recipe_10_07.h"

int main()
{
   recipe_10_01::execute();
   recipe_10_02::execute();
   recipe_10_03::execute();
   recipe_10_04::execute();
   recipe_10_05::execute();
   recipe_10_06::execute();
   recipe_10_07::execute();
}